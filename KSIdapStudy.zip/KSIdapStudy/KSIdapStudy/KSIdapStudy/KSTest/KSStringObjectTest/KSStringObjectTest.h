//
//  KSStringObjectTest.h
//  KSIdapStudy
//
//  Created by KulikovS on 22.01.16.
//  Copyright © 2016 KulikovS. All rights reserved.
//

#ifndef KSStringObjectTest_h
#define KSStringObjectTest_h

#include <stdio.h>

#include "KSStringObject.h"
#include "KSObject.h"

extern
void KSStringObjectTest(void);

#endif /* KSStringObjectTest_h */
