//
//  KSHumanTest.h
//  KSIdapStudy
//
//  Created by KulikovS on 09.01.16.
//  Copyright © 2016 KulikovS. All rights reserved.
//

#ifndef KSHumanTest_h
#define KSHumanTest_h

#include "KSHuman.h"


extern
void KSHumanTest(void);

#endif /* KSHumanTest_h */
