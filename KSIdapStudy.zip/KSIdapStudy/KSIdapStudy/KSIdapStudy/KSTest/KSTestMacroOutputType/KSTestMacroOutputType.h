//
//  KSTestOutputType.h
//  KSMacrosPrintOutputType
//
//  Created by KulikovS on 26.12.15.
//  Copyright © 2015 KulikovS. All rights reserved.
//

#ifndef KSTestMacroOutputType_h
#define KSTestMacroOutputType_h

extern
void KSTestMacroOutputType(void);

#endif /* KSTestOutputType_h */
