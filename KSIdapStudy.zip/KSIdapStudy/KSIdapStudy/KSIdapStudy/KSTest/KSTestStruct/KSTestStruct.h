//
//  KSTestCarStruct.h
//  KSMacros
//
//  Created by KulikovS on 28.12.15.
//  Copyright © 2015 KulikovS. All rights reserved.
//

#ifndef KSTestCarStruct_h
#define KSTestCarStruct_h

#include "KSStruct.h"

void KSTestCarStruct();

#endif /* KSTestCarStruct_h */
