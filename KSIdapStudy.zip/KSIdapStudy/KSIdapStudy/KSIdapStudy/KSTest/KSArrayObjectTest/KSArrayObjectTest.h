//
//  KSArrayObjectTest.h
//  KSIdapStudy
//
//  Created by KulikovS on 26.01.16.
//  Copyright © 2016 KulikovS. All rights reserved.
//

#ifndef KSArrayObjectTest_h
#define KSArrayObjectTest_h

#include <stdio.h>

#include "KSArrayObject.h"

extern
void KSArrayObjectTest(void);

#endif /* KSArrayObjectTest_h */
