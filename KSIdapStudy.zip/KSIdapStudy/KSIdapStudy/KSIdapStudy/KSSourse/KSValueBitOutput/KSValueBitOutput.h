//
//  KSValueBitOutput.h
//  KSIdapStudy
//
//  Created by KulikovS on 04.01.16.
//  Copyright © 2016 KulikovS. All rights reserved.
//

#ifndef KSValueBitOutput_h
#define KSValueBitOutput_h

#include <stdlib.h>
#include <stddef.h>

extern
void KSPrintByteValueOutput(void *value, size_t size);

#endif /* KSValueBitOutput_h */
